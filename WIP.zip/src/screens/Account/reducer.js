import { reduxState } from '../../store/index'

export default (state = reduxState, action) => {

}