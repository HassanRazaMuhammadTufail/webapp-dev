import React, { Component } from 'react'
// import { connect } from 'react-redux'

export class UserAccount extends Component {
    render() {
        return (
            <div>
                Account
            </div>
        )
    }
}

// function mapStateToProp(state) {
//     return ({
     
//     })
// }
// function mapDispatchToProp(dispatch) {
//     return ({
    
//         // adminLogin: (admin)=>{
//         //     dispatch(adminLogin(admin))
//         // }
//     })
// }

// export default connect(mapStateToProp, mapDispatchToProp)(Account);