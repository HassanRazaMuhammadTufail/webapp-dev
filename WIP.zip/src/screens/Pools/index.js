import React, { Component } from "react";
// import { connect } from 'react-redux'
import "./style.css";

export class Pools extends Component {
  render() {
    return (
      <div className="pools-main">
        <div className="pools-container">
          <h1 className="heading">Pools</h1>
          <div className="pools-details">
            <h1 className="prize-amount">
                $1,000
            </h1>
            <p>This week's prize value*</p>
          </div>
        </div>
      </div>
    );
  }
}

// function mapStateToProp(state) {
//     return ({

//     })
// }
// function mapDispatchToProp(dispatch) {
//     return ({

//         // adminLogin: (admin)=>{
//         //     dispatch(adminLogin(admin))
//         // }
//     })
// }

// export default connect(mapStateToProp, mapDispatchToProp)(Pools);
