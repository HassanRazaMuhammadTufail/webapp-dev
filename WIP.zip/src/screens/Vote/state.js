const voteState = {

}

export default voteState;