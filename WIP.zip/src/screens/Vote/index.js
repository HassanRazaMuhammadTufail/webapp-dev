import React, { Component } from 'react'
// import { connect } from 'react-redux'

export class Vote extends Component {
    render() {
        return (
            <div>
                Vote
            </div>
        )
    }
}

// function mapStateToProp(state) {
//     return ({
     
//     })
// }
// function mapDispatchToProp(dispatch) {
//     return ({
    
//         // adminLogin: (admin)=>{
//         //     dispatch(adminLogin(admin))
//         // }
//     })
// }

// export default connect(mapStateToProp, mapDispatchToProp)(Vote);