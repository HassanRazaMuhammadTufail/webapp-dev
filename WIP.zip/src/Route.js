import React, { Component } from "react";
import { Navbar } from "./components/Navbar";
import { Route, BrowserRouter, Switch } from "react-router-dom";
import { Pools } from "./screens/Pools";
import { Vote } from "./screens/Vote";
import { UserAccount } from "./screens/Account";
import { Drawer } from "./components/Drawer";
import './App.css';

class AppRoutes extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <Navbar />
          <Drawer />
          <Switch>
            <Route exact path="/" component={Pools} />
            <Route path="/vote" component={Vote} />
            <Route path="/account" component={UserAccount} />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

export default AppRoutes;
