import { createStore } from 'redux';
import voteState from '../screens/Vote/state';
import poolState from '../screens/Pools/state';
import accountState from '../screens/Account/state';

export const reduxState = {
    ...voteState,
    ...poolState,
    ...accountState
}



const store = createStore(reduxState);

export default store;

import rootReducer from './reducer';
import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';

const store = createStore(
    rootReducer,
    {},
    applyMiddleware(thunk)
);

export default store;